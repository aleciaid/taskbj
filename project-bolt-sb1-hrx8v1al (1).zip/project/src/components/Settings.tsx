import { useState, useEffect } from 'react';
import { Save, Webhook, AlertCircle, CheckCircle } from 'lucide-react';

interface SettingsProps {
  webhookUrl: string;
  onSave: (url: string) => void;
}

export function Settings({ webhookUrl, onSave }: SettingsProps) {
  const [url, setUrl] = useState(webhookUrl);
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    setUrl(webhookUrl);
  }, [webhookUrl]);

  const handleSave = () => {
    onSave(url);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <div className="max-w-2xl">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
            <Webhook className="text-blue-600 dark:text-blue-400" size={24} />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              Konfigurasi Webhook
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Data akan dikirim ke URL ini setelah task disimpan
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label htmlFor="webhook-url" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Webhook URL
            </label>
            <input
              type="url"
              id="webhook-url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://example.com/webhook"
              className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
            />
          </div>

          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
            <div className="flex gap-2">
              <AlertCircle className="text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" size={18} />
              <div className="text-sm text-blue-800 dark:text-blue-200">
                <p className="font-medium mb-1">Format Payload:</p>
                <pre className="text-xs bg-white dark:bg-gray-800 p-2 rounded mt-2 overflow-x-auto">
{`{
  "id": "string",
  "nama": "string",
  "jabatan": "string",
  "no_telp": "string",
  "informasi": "string",
  "jenis_task": "string",
  "jenis_task_custom": "string | null",
  "created_at": "ISO date string",
  "status": "pending"
}`}
                </pre>
              </div>
            </div>
          </div>

          <button
            onClick={handleSave}
            className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-lg transition-colors"
          >
            {isSaved ? (
              <>
                <CheckCircle size={20} />
                <span>Tersimpan!</span>
              </>
            ) : (
              <>
                <Save size={20} />
                <span>Simpan Konfigurasi</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
