import { useState, FormEvent } from 'react';
import { Task, JenisTask } from '../types/task';
import { generateId, validatePhoneNumber } from '../utils/helpers';
import { AlertCircle } from 'lucide-react';

interface TaskFormProps {
  onSubmit: (task: Task) => void;
  isLoading?: boolean;
}

interface FormErrors {
  nama?: string;
  jabatan?: string;
  no_telp?: string;
  informasi?: string;
  jenis_task?: string;
  jenis_task_custom?: string;
}

export function TaskForm({ onSubmit, isLoading = false }: TaskFormProps) {
  const [formData, setFormData] = useState({
    nama: '',
    jabatan: '',
    no_telp: '',
    informasi: '',
    jenis_task: '',
    jenis_task_custom: ''
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const validate = (): boolean => {
    const newErrors: FormErrors = {};

    if (!formData.nama.trim()) {
      newErrors.nama = 'Nama harus diisi';
    }

    if (!formData.jabatan.trim()) {
      newErrors.jabatan = 'Jabatan harus diisi';
    }

    if (!formData.no_telp.trim()) {
      newErrors.no_telp = 'No Telp harus diisi';
    } else if (!validatePhoneNumber(formData.no_telp)) {
      newErrors.no_telp = 'No Telp harus berupa angka';
    }

    if (!formData.informasi.trim()) {
      newErrors.informasi = 'Informasi harus diisi';
    }

    if (!formData.jenis_task) {
      newErrors.jenis_task = 'Jenis Task harus dipilih';
    }

    if (formData.jenis_task === 'Lainnya' && !formData.jenis_task_custom.trim()) {
      newErrors.jenis_task_custom = 'Jenis Task Lainnya harus diisi';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();

    const allTouched = Object.keys(formData).reduce((acc, key) => ({
      ...acc,
      [key]: true
    }), {});
    setTouched(allTouched);

    if (!validate()) {
      return;
    }

    const task: Task = {
      id: generateId(),
      nama: formData.nama.trim(),
      jabatan: formData.jabatan.trim(),
      no_telp: formData.no_telp.trim(),
      informasi: formData.informasi.trim(),
      jenis_task: formData.jenis_task as JenisTask,
      jenis_task_custom: formData.jenis_task === 'Lainnya' ? formData.jenis_task_custom.trim() : null,
      created_at: new Date().toISOString(),
      status: 'pending'
    };

    onSubmit(task);

    setFormData({
      nama: '',
      jabatan: '',
      no_telp: '',
      informasi: '',
      jenis_task: '',
      jenis_task_custom: ''
    });
    setTouched({});
    setErrors({});
  };

  const handleBlur = (field: string) => {
    setTouched({ ...touched, [field]: true });
    validate();
  };

  const handleChange = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value });
    if (touched[field]) {
      validate();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="nama" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Nama
        </label>
        <input
          type="text"
          id="nama"
          value={formData.nama}
          onChange={(e) => handleChange('nama', e.target.value)}
          onBlur={() => handleBlur('nama')}
          className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-colors"
          disabled={isLoading}
        />
        {touched.nama && errors.nama && (
          <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center gap-1">
            <AlertCircle size={14} />
            {errors.nama}
          </p>
        )}
      </div>

      <div>
        <label htmlFor="jabatan" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Jabatan
        </label>
        <input
          type="text"
          id="jabatan"
          value={formData.jabatan}
          onChange={(e) => handleChange('jabatan', e.target.value)}
          onBlur={() => handleBlur('jabatan')}
          className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-colors"
          disabled={isLoading}
        />
        {touched.jabatan && errors.jabatan && (
          <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center gap-1">
            <AlertCircle size={14} />
            {errors.jabatan}
          </p>
        )}
      </div>

      <div>
        <label htmlFor="no_telp" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          No Telp
        </label>
        <input
          type="tel"
          id="no_telp"
          value={formData.no_telp}
          onChange={(e) => handleChange('no_telp', e.target.value)}
          onBlur={() => handleBlur('no_telp')}
          className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-colors"
          disabled={isLoading}
        />
        {touched.no_telp && errors.no_telp && (
          <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center gap-1">
            <AlertCircle size={14} />
            {errors.no_telp}
          </p>
        )}
      </div>

      <div>
        <label htmlFor="jenis_task" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Jenis Task
        </label>
        <select
          id="jenis_task"
          value={formData.jenis_task}
          onChange={(e) => handleChange('jenis_task', e.target.value)}
          onBlur={() => handleBlur('jenis_task')}
          className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-colors"
          disabled={isLoading}
        >
          <option value="">Pilih Jenis Task</option>
          <option value="Maintenance">Maintenance</option>
          <option value="Pembelian">Pembelian</option>
          <option value="Lainnya">Lainnya</option>
        </select>
        {touched.jenis_task && errors.jenis_task && (
          <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center gap-1">
            <AlertCircle size={14} />
            {errors.jenis_task}
          </p>
        )}
      </div>

      {formData.jenis_task === 'Lainnya' && (
        <div className="animate-in slide-in-from-top-2">
          <label htmlFor="jenis_task_custom" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Jenis Task Lainnya
          </label>
          <input
            type="text"
            id="jenis_task_custom"
            value={formData.jenis_task_custom}
            onChange={(e) => handleChange('jenis_task_custom', e.target.value)}
            onBlur={() => handleBlur('jenis_task_custom')}
            className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-colors"
            placeholder="Masukkan jenis task"
            disabled={isLoading}
          />
          {touched.jenis_task_custom && errors.jenis_task_custom && (
            <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center gap-1">
              <AlertCircle size={14} />
              {errors.jenis_task_custom}
            </p>
          )}
        </div>
      )}

      <div>
        <label htmlFor="informasi" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Informasi
        </label>
        <textarea
          id="informasi"
          value={formData.informasi}
          onChange={(e) => handleChange('informasi', e.target.value)}
          onBlur={() => handleBlur('informasi')}
          rows={4}
          className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-colors resize-none"
          disabled={isLoading}
        />
        {touched.informasi && errors.informasi && (
          <p className="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center gap-1">
            <AlertCircle size={14} />
            {errors.informasi}
          </p>
        )}
      </div>

      <button
        type="submit"
        disabled={isLoading}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-lg transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
      >
        {isLoading ? 'Menyimpan...' : 'Simpan Task'}
      </button>
    </form>
  );
}
